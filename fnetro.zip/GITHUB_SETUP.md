# Publishing Fono to GitHub & npm

A step-by-step guide from zero to public package.

---

## 1. GitHub repository

### Create the repo

```bash
# In your monorepo root
git init
git add -A
git commit -m "chore: initial commit"
```

Go to [github.com/new](https://github.com/new) and create a repository named `fono`.

```bash
git remote add origin https://github.com/YOUR_USERNAME/fono.git
git branch -M main
git push -u origin main
```

### Repository settings

In your GitHub repo → **Settings**:

1. **Secrets → Actions** → Add these secrets:
   - `NPM_TOKEN` — your npm access token (see section 3)

2. **Branch protection** (recommended):
   - Protect `main`, require PR reviews, require CI to pass

3. **Pages** (optional for docs):
   - Source: `gh-pages` branch or `/docs` folder

---

## 2. Update package.json — add your details

In `packages/fono/package.json` and `packages/create-fono/package.json`, replace:

```json
{
  "author": "Your Name <you@example.com>",
  "repository": {
    "url": "git+https://github.com/YOUR_USERNAME/fono.git"
  },
  "homepage": "https://github.com/YOUR_USERNAME/fono#readme",
  "bugs": { "url": "https://github.com/YOUR_USERNAME/fono/issues" }
}
```

Also update the badge URLs in `README.md`:
```md
[![npm](https://img.shields.io/npm/v/fono)](https://www.npmjs.com/package/fono)
```
→ replace `your-org` with your GitHub username.

---

## 3. npm account & token

### Create account

Go to [npmjs.com](https://www.npmjs.com) and sign up if you haven't.

### Claim the package name

```bash
# Login
npm login

# Check availability
npm view fono         # if "404 Not Found" → name is free
npm view create-fono  # same check
```

If `fono` is taken, use a scoped name:
```json
{ "name": "@yourname/fono" }
```
And update the peer dependency in `create-fono` accordingly.

### Create an automation token

1. npmjs.com → your avatar → **Access Tokens**
2. **Generate New Token** → **Automation** (works in CI without 2FA)
3. Copy the token — you won't see it again

Add it to GitHub Secrets as `NPM_TOKEN`.

---

## 4. First manual publish

Before the CI pipeline takes over, do the first publish manually to claim the names.

```bash
cd packages/fono
npm run build        # generates dist/
npm publish --access public

cd ../create-fono
npm run build
npm publish --access public
```

For scoped packages:
```bash
npm publish --access public  # scoped packages are private by default
```

Verify:
```bash
npm view fono
npm view create-fono
```

---

## 5. Automated releases via Changesets

The repo uses [Changesets](https://github.com/changesets/changesets) for versioning.

### Install the CLI (once)

```bash
npm install -g @changesets/cli
```

### Workflow

**When you make a change that warrants a release:**

```bash
# 1. Describe the change
npx changeset
# → Select packages affected
# → Choose semver bump (patch / minor / major)
# → Write a summary
# This creates a file in .changeset/

# 2. Commit the changeset file
git add .changeset/
git commit -m "chore: add changeset for X"
git push
```

**The Release GitHub Action then:**
1. Detects the new changeset file
2. Opens a "Version Packages" PR that bumps `package.json` versions and updates `CHANGELOG.md`
3. When you merge that PR → automatically publishes to npm

### Release PR example

```
chore: release packages

Packages:
 - fono@0.2.0
 - create-fono@0.2.0
```

### Hotfix / patch

```bash
npx changeset          # select "patch", write "fix: ..."
git add .changeset/ && git push
# → CI opens version PR → merge → publish
```

---

## 6. GitHub Actions explained

### `ci.yml` — runs on every PR and push to `main`

```
1. Checkout code
2. Setup Node (matrix: 18, 20, 22)
3. npm ci
4. Typecheck fono
5. Build fono
6. Typecheck create-fono
7. Build create-fono
8. Scaffold smoke test (runs create-fono, checks files exist)
```

### `publish.yml` — runs only on push to `main`

```
1. Checkout (full history for changeset)
2. Build all packages
3. changesets/action:
   - If .changeset/ files exist → open "Version Packages" PR
   - If triggered by merging that PR → npm publish
```

The publish step uses `NPM_TOKEN` from secrets and `--provenance` for npm audit trail.

---

## 7. Local development workflow

```bash
# Clone
git clone https://github.com/YOUR_USERNAME/fono.git
cd fono

# Install all workspaces
npm install

# Build everything
npm run build

# Typecheck everything
npm run typecheck

# Work on fono
cd packages/fono
npm run build:watch   # watch mode

# Test create-fono locally
node packages/create-fono/dist/index.js test-project
```

### Test fono in a local app

```bash
# In packages/fono
npm link

# In your test app
npm link fono
```

Or use `npm pack` + install the tarball:

```bash
cd packages/fono
npm pack           # creates fono-0.1.0.tgz
cd /tmp/test-app
npm install /path/to/fono-0.1.0.tgz
```

---

## 8. Versioning strategy

| Change | Bump | Example |
|---|---|---|
| Bug fix, internal improvement | `patch` | `0.1.0` → `0.1.1` |
| New feature, backwards compatible | `minor` | `0.1.0` → `0.2.0` |
| Breaking API change | `major` | `0.1.0` → `1.0.0` |

Keep `fono` and `create-fono` in sync — they're linked in `.changeset/config.json`:
```json
{ "linked": [["fono", "create-fono"]] }
```
Both packages will always share the same version.

---

## 9. Post-publish checklist

- [ ] `npm view fono` shows the correct version
- [ ] `npx create-fono test` scaffolds a working project
- [ ] GitHub release is created with changelog (Changesets does this automatically)
- [ ] README badges show correct version numbers
- [ ] Test on Node 18, 20, 22: `node dist/server/server.js`
- [ ] Test on Bun: `bun dist/server/server.js`

---

## 10. Directory structure (final)

```
fono/                              ← GitHub repo root
├── .github/
│   └── workflows/
│       ├── ci.yml                 ← typecheck + build + scaffold test
│       └── publish.yml            ← Changesets → npm publish
├── .changeset/
│   └── config.json
├── packages/
│   ├── fono/                      ← npm package: fono
│   │   ├── core.ts                ← reactivity + types
│   │   ├── server.ts              ← Hono app + SSR + Vite plugin
│   │   ├── client.ts              ← SPA runtime
│   │   ├── dist/                  ← built output (gitignored)
│   │   ├── tsup.config.ts
│   │   ├── tsconfig.json
│   │   └── package.json
│   └── create-fono/               ← npm package: create-fono
│       ├── src/index.ts           ← CLI scaffolder
│       ├── dist/                  ← built output (gitignored)
│       ├── tsconfig.json
│       └── package.json
├── package.json                   ← npm workspaces root
├── .gitignore
├── LICENSE
└── README.md
```
